// Simple contact form handler (no backend). It shows a thank-you and resets.
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('contactForm');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    alert('Merci! Votre message a été pris en compte. Nous vous contacterons bientôt.');
    form.reset();
  });
});
