# Déneigement JMR - One Page Site

Dossier prêt à être glissé dans un dépôt GitHub Pages ou hébergé sur Netlify / Vercel.

## Contenu
- `index.html` — page principale
- `style.css` — styles
- `script.js` — petit script pour le formulaire
- `assets/` — dossier pour les images

## IMPORTANT : ajouter vos images dans `assets/`
Placez dans `assets/` :
- `logo-jmr.png`  (votre logo)
- `flocon-bleu.png` (grand flocon en fond — optionnel)

## Déployer sur GitHub Pages
1. Créer un nouveau dépôt GitHub.
2. Glisser-déposer tous les fichiers (ou `git push`) dans le repo.
3. Aller dans **Settings > Pages** et choisir la branche `main` / `/ (root)`.
4. Votre site sera disponible à `https://<votre-username>.github.io/<repo-name>/`

## Tester localement
Ouvrez `index.html` dans votre navigateur (double-cliquez).  
Si les images ne s'affichent pas, vérifiez qu'elles sont bien dans `assets/` avec les bons noms.
